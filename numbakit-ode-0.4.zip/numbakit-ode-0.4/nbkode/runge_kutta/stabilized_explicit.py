from .explicit import ERK


class SERK(ERK):
    """Stabilized Explicit Runge-Kutta (SERK) method."""

    pass
