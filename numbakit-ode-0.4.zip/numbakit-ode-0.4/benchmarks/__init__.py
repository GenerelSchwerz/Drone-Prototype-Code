"""
    benchmarks
    ~~~~~~~~~~

    Measure, as much as you can.

    :copyright: 2020 by nbkode Authors, see AUTHORS for more details.
    :license: BSD, see LICENSE for more details.
"""
